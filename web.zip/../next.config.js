/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      remotePatterns: [
        {
          protocol: 'http',
          hostname: process.env.IMAGE_PATTERN,
          port: '8080'
        }
      ],
    },
    output: "standalone",
}

console.log('config', nextConfig)

module.exports = nextConfig
